//create the global variables for the game
var monkey, monkey_running;
var banana, bananaImage, obstacle, obstacleImage;
var FoodGroup, obstacleGroup;
var score;
var ground;
var survivalTime = 0;

function preload() {

  //load the animations
  monkey_running = loadAnimation("sprite_0.png", "sprite_1.png", "sprite_2.png", "sprite_3.png", "sprite_4.png", "sprite_5.png", "sprite_6.png", "sprite_7.png", "sprite_8.png")

  //load the images
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");

}



function setup() {
  //create a canvas
  createCanvas(500, 200);

  //create the ground
  ground = createSprite(200,180,998,10);
  ground.velocityX = -4;
  ground.x = ground.width/2;
  
  //create the monkey
  monkey = createSprite(50,150,20,20);
  monkey.addAnimation("running",monkey_running);
  monkey.scale = 0.1;
}


function draw() {
  //create background
  background("lightgreen");
  
  //make the ground repeat itself
  if (ground.x < 0){
      ground.x = ground.width/2;
    }
  
  //make the monkey jump when space key is pressed
  if(keyDown("space")){
    monkey.velocityY = -12;
  }
  
  //give gravity to the monkey
  monkey.velocityY = monkey.velocityY + 0.8;
  
  //collide the monkey with the ground
  monkey.collide(ground);
 
  //call the functions
  spawnObstacles();
  spawnBananas(); 
  
  //display the survival time
  stroke("black");
  textSize(20);
  fill("black");
  survivalTime = Math.ceil(frameCount/frameRate());
  text("Survival Time:" + survivalTime,190,30);
  
 drawSprites();


}

//create the obstacles function
function spawnObstacles(){
 if (frameCount % 80 === 0){
   obstacle = createSprite(600,160,10,40);
   obstacle.velocityX = -4;
   obstacle.addImage(obstacleImage);
   obstacle.scale = 0.1;
 }
 }

//create the bananas function
function spawnBananas(){
  if (frameCount % 60 === 0){
    banana = createSprite(600,Math.round(random(20,100)),20,20);
    banana.velocityX = -4;
    banana.addImage(bananaImage);
    banana.scale = 0.1;
  }
}
   